package com.example.tamiltranslatoronboarding.network

data class SignupRequest(
    val name: String,
    val email: String,
    val password: String
)

data class VerifyRequest(
    val email: String,
    val code: String
)

data class LoginRequest(
    val email: String,
    val password: String
)

data class ApiResponse(
    val success: Boolean,
    val message: String,
    val token: String? = null
)

data class SendCodeRequest(
    val email: String
)